package pl.com.autostopowicz.pagemodel;

import pl.com.autostopowicz.database.DatabaseManager;

public class MainPageBean {
	DatabaseManager dataSource;  
	
	public MainPageBean(DatabaseManager dataSource){
		this.dataSource = dataSource;
		
	}
	
	public MainPageBean(){
		
	}
	
	public String getPozdrowienia() {
	        return "Pozdrowienia od ziarna ze Spring Framework";
	    }



	public DatabaseManager getDataSource() {
		return dataSource;
	}



	public void setDataSource(DatabaseManager dataSource) {
		this.dataSource = dataSource;
	}
	
}
