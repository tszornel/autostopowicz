package pl.com.autostopowicz.database;

import java.util.List;

public interface DatabaseManager {
	
	public static final int ROLE_ADMIN = 1;

	public static final int ROLE_USER = 2;
	

	/*
	public List getUsers();

	public User getUser(int userId);

	public User saveUser(User user);

	public void removeUser(int userId);
	
	public User getUser(String login);
	*/
	
	
	
}
