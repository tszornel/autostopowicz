package pl.com.autostopowicz.controller;

import java.io.IOException;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pl.com.autostopowicz.database.DatabaseManager;

public class StartPageController{
	  //~ Instance fields ------------------------------------------------------------------------------------------------

    /** Logger for this class and subclasses */
    protected final Log logger = LogFactory.getLog(getClass());

    /** TODO: DOCUMENT ME! */
    private DatabaseManager dataSource;
    
    public String hello = "HELLO";

    //~ Methods --------------------------------------------------------------------------------------------------------

    /**
     *  
    DOCUMENT ME!
     *
     *  @param request TODO: DOCUMENT ME!
     *  @param response TODO: DOCUMENT ME!
     *
     *  @return TODO: DOCUMENT ME!
     *
     *  @throws ServletException TODO: DOCUMENT ME!
     *  @throws IOException TODO: DOCUMENT ME!
     *
     * 
     */
    /*public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
    	logger.info("returning start page view ");
        
    	String language = request.getParameter("language");
        MainPageBean model = new MainPageBean(dataSource);
        //	Check authorization
        String lfGet = request.getParameter("lf");

        int lf = 0;
        try{
        	lf = Integer.parseInt(lfGet);
        	if(lf == 1){
            	model.setLoginFailed(true);
        	}
        	if(lf == 2){
            	model.setNoPermission(true);
        	}
        	
        }catch(NumberFormatException e){
        }
          
       // model.fetchData();
        if (language != null && language.equals("pl")){
        	return new ModelAndView("Home", "model", model);
        }else  if (language != null && language.equals("pl")){
        	return new ModelAndView("Home-english", "model", model);
        	
        }else{
        	return new ModelAndView("Home", "model", model);
        }
        
    	}*/

    
    
    public String tomsSetup(){
    	//FacesContext context = FacesContext.getCurrentInstance();

    	//String value = (String)(context.getExternalContext().getRequestParameterValuesMap().get("cid"));
    //	logger.debug("TOMSSSSSSSSSSS"+value);
    	return "toms";
    }

    /**
     *  
    DOCUMENT ME!
     *
     *  @param dataSource the dataSource to set
     */
    public void setDataSource(DatabaseManager dataSource) {
        this.dataSource = dataSource;
    }                               
}
